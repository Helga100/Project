package view_layer;

public class LoginMenu {

}
