package com.company;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Main {

    private static void start(ArrayList<User> dbUsers, ArrayList<Product> dbProducts, ArrayList<Order> dbOrders) {
        while (true) {
            mainMenu();

            Scanner scanner = new Scanner(System.in);
            final int choice1 = scanner.nextInt();
            scanner.nextLine();                    // skip /n

            if (choice1 == 1) {
                signingIn(dbUsers, dbProducts, scanner, dbOrders);

            }
            if (choice1 == 2) {
                registration(dbUsers, scanner);

            }
        }
    }

    public static void main(String[] args) {
        ArrayList<User> dbUsers = new ArrayList<>();
        dbUsers.add(new User("1", "1", "1"));
        dbUsers.add(new User("2", "2", true, "2"));   // admin
        ArrayList<Product> dbProducts = new ArrayList<Product>();
        ArrayList<Order> dbOrders = new ArrayList<>();
        dbOrders.add(new Order(new Product("Shoes", "36", "Grey", "boy", 7, "SHOES", 11), "2"));
        dbProducts.add(new Product("Jacket", "M", "Blue", "boy", 10, "OUTWEAR", 1));
        dbProducts.add(new Product("Coat", "M", "Black", "boy", 9, "OUTWEAR", 2));
        dbProducts.add(new Product("Trousers", "S", "White", "boy", 10, "TROUSERS", 3));
        dbProducts.add(new Product("Trousers", "M", "Brown", "boy", 7, "TROUSERS", 4));
        dbProducts.add(new Product("Shirt", "M", "White", "boy", 9, "SHIRTS", 5));
        dbProducts.add(new Product("Shirt", "S", "Blue", "boy", 10, "SHIRTS", 6));
        dbProducts.add(new Product("Shirt", "S", "Green", "boy", 20, "SHIRTS", 7));
        dbProducts.add(new Product("Suit", "S", "Blue", "boy", 10, "SUITS", 8));
        dbProducts.add(new Product("Suit", "L", "Brown", "boy", 7, "SUITS", 9));
        dbProducts.add(new Product("Shoes", "40", "Brown", "boy", 12, "SHOES", 10));
        dbProducts.add(new Product("Shoes", "36", "Grey", "boy", 7, "SHOES", 11));
        dbProducts.add(new Product("Dress", "S", "yellow", "girl", 5, "DRESSES", 12));
        dbProducts.add(new Product("Dress", "L", "Blue", "girl", 10, "DRESSES", 13));
        dbProducts.add(new Product("Coat", "S", "Blue", "girl", 12, "OUTWEAR", 14));
        dbProducts.add(new Product("Jacket", "M", "Grey", "girl", 9, "OUTWEAR", 15));
        dbProducts.add(new Product("Jacket", "L", "Black", "girl", 15, "OUTWEAR", 16));
        dbProducts.add(new Product("Trousers", "S", "Black", "girl", 12, "TROUSERS", 17));
        dbProducts.add(new Product("Trousers", "L", "White", "girl", 8, "TROUSERS", 18));
        dbProducts.add(new Product("Blouse", "S", "White", "girl", 10, "BLOUSES", 19));
        dbProducts.add(new Product("Blouse", "M", "Yellow", "girl", 7, "BLOUSES", 20));
        dbProducts.add(new Product("Suits", "L", "Green", "girl", 9, "SUITS", 21));
        dbProducts.add(new Product("Suits", "S", "White", "girl", 14, "SUITS", 22));
        dbProducts.add(new Product("Shoes", "37", "Black", "girl", 10, "SHOES", 23));
        dbProducts.add(new Product("Shoes", "39", "Blue", "girl", 14, "SHOES", 24));
        dbProducts.add(new Product("Skirt", "M", "Blue", "girl", 9, "SKIRTS", 25));
        dbProducts.add(new Product("Skirt", "S", "Black", "girl", 12, "SKIRTS", 26));


        greeting();

        start(dbUsers, dbProducts, dbOrders);

    }

    private static void registration(ArrayList<User> dbUsers, Scanner scanner) {
        System.out.println("Register page: ");
        System.out.println("Create login: ");
        String login = scanner.nextLine();
        System.out.println("Create password: ");
        String password = scanner.nextLine();
        User tempUser = new User(login, password, "3");  //TODO Increment ID
        if (dbUsers.contains(tempUser)) {
            System.out.println("User exists, try to log in");
        } else {
            dbUsers.add(tempUser);  //TODO Increment ID
            System.out.println("Your registration is successful");
        }
    }

    private static void mainMenu() {
        System.out.println("Login menu: ");
        System.out.println("1. Login");
        System.out.println("2. Register");
        System.out.println("0. Exit");
    }

    private static void greeting() {
        System.out.println("Welcome to our store!. The best clothes for your kids!");
    }

    /*
          Login as user:

       System.out.println("Login menu: ");
       System.out.println("1. Login");

     */
    private static void signingIn(ArrayList<User> dbUsers, ArrayList<Product> dbProducts, Scanner scanner, ArrayList<Order> dbOrders) {
        System.out.println("Input login: ");
        final String loginFromConcole = scanner.nextLine();
        System.out.println("Input password: ");
        final String passwordFromConcole = scanner.nextLine();
        final User foundUser = dbUsers.stream()
                .filter(it -> it.login.equals(loginFromConcole) && it.password.equals(passwordFromConcole))
                .findFirst().orElse(null);

        if (foundUser != null) {
            if (isAdmin(foundUser, dbUsers)) {
                adminMenu(dbProducts, scanner, dbOrders, dbUsers);
            } else {
                if (foundUser.isBlocked) {
                    System.out.println("Sorry you are blocked");
                } else {
                    userMenu(dbProducts, scanner, dbOrders, dbUsers);
                }
            }

        } else {
            System.out.println("Please check Login or Password");
        }

//            PrintWriter writer = new PrintWriter("the-file-name.txt", "UTF-8");
//            writer.println("The first line");
//            writer.println("The second line");
//            writer.close();
    }

    private static void adminMenu(ArrayList<Product> dbProducts, Scanner scanner, ArrayList<Order> dbOrders, ArrayList<User> dbUsers) {
        System.out.println("Welcome to Admin Page");
        System.out.println("1. Users menu (block/unblock)");
        System.out.println("2. Order menu (confirm/unconfirm order)");
        System.out.println("3. Products menu (edit / add)");
        System.out.println("4. Log out");
        System.out.println("Please make the choice");
        final String choceAdmin1 = scanner.nextLine();
        if (choceAdmin1.equals("1")) {
            System.out.println("List of users: ");
            System.out.println(dbUsers);
            System.out.println("Input id user");
            String scannerIdUser = scanner.nextLine();
            final User userById = dbUsers.stream().filter(it -> it.ID.equals(scannerIdUser))
                    .collect(Collectors.toList())
                    .get(0);
            System.out.println(userById);
            System.out.println("Block / Unblock Status User: " + userById.isBlocked);
            System.out.println("1. Block this User");
            System.out.println("2. Unblock this User");
            final String blockChoice = scanner.nextLine();
            if (blockChoice.equals("1")) {
//                User userByIdWithBlockStatus = new User(userById.login, userById.password,"100");
                userById.isBlocked = true;
                dbUsers.stream().filter(it -> it.ID.equals(scannerIdUser))
                        .forEach(it -> it = userById);
                System.out.println("User is blocked");

            } else if (blockChoice.equals("2")) {
                userById.isBlocked = false;
                dbUsers.stream().filter(it -> it.ID.equals(scannerIdUser))
                        .forEach(it -> it = userById);
                System.out.println("User is unblocked");
            }
        } else if (choceAdmin1.equals("2")) {
            System.out.println("Welcome to order menu");
            System.out.println("List of Orders: " + dbOrders);
            System.out.println("Please input order ID");
            String orderId = scanner.nextLine();
            Order orderInWork = dbOrders.stream()
                    .filter(it -> orderId.equals(it.id))
                    .findFirst()
                    .get();

            System.out.println("1.Confirm order");
            System.out.println("2.Unconfirm order");
            final String s = scanner.nextLine();
            if (s.equals("1")) {
                orderInWork.orderStatus = OrderStatus.CONFIRM;
                dbOrders.stream().filter(it -> it.id.equals(orderId))
                        .forEach(it -> it = orderInWork);
                System.out.println("Order confirmed");
            } else if (s.equals("2")) {
                orderInWork.orderStatus = OrderStatus.UNCONFIRM;
                dbOrders.stream().filter(it -> it.id.equals(orderId))
                        .forEach(it -> it = orderInWork);
                System.out.println("Order unconfirmed");
            }

        } else if (choceAdmin1.equals("3")) {
            System.out.println("Products menu (Admin)");
            System.out.println("a. Edit existing product details");
            System.out.println("b. Add new product");
            final String choiceAdminInProductMenu = scanner.nextLine();
            if (choiceAdminInProductMenu.equals("a")) {
                System.out.println("Input product ID ");
                final String idProduct = scanner.nextLine();
                System.out.println("Input colorProduct ");
                final String newColorProduct = scanner.nextLine();
                dbProducts.stream()
                        .filter(it -> it.id == Integer.parseInt(idProduct))
                        .forEach(it -> it.color = newColorProduct);
                System.out.println(getProductById(dbProducts, idProduct));
            } else if (choiceAdminInProductMenu.equals("b")) {
                System.out.println("Please input name of the product");
                String newProductName = scanner.nextLine();

                System.out.println("Please input size of the product");
                String newProductSize = scanner.nextLine();

                System.out.println("Please input color of the product");
                String newProductColor = scanner.nextLine();

                System.out.println("Please input sex of the product");
                String newProductSex = scanner.nextLine();

                System.out.println("Please input age of the product");
                int age = scanner.nextInt();
                scanner.nextLine();
                System.out.println("Please input category of the product");
                String newProductCategory = scanner.nextLine();

                System.out.println("Please input id of the product");
                int id = scanner.nextInt();
                scanner.nextLine();
                dbProducts.add(new Product(newProductName, newProductSize, newProductColor, newProductSex, age, newProductCategory, id));
            }
        } else if (choceAdmin1.equals("4")) {
            start(dbUsers, dbProducts, dbOrders);

        }
        adminMenu(dbProducts, scanner, dbOrders, dbUsers);
    }

    private static boolean isAdmin(User tempUser, ArrayList<User> dbUsers) {
        final List<User> collect = dbUsers.stream().filter(it -> it.login.equals(tempUser.login))
                .collect(Collectors.toList());

        return collect.get(0).isAdmin;
    }

    private static void userMenu(ArrayList<Product> dbProducts, Scanner scanner, ArrayList<Order> dbOrders, ArrayList<User> dbUsers) {

        System.out.println("1. Products menu: ");
        System.out.println("2. My orders menu: ");
        final int choice2 = scanner.nextInt();
        scanner.nextLine();                    // skip /n
        if (choice2 == 1) {

            while (true) {
                productMenu(dbProducts, scanner, dbOrders, dbUsers);
            }

        }
        if (choice2 == 2) {
            System.out.println("Your orders: " + dbOrders);
        }
    }

    private static void productMenu(ArrayList<Product> dbProducts, Scanner scanner, ArrayList<Order> dbOrders, ArrayList<User> dbUsers) {
        System.out.println("Products menu: ");
        System.out.println("a. List of all products: ");
        System.out.println("b. Search for specific product: ");
        System.out.println("c. Order checkout: ");
        System.out.println("d. Return to User Menu: ");
        System.out.println("e. Log Out ");
        final String choice3 = scanner.nextLine();
        if (choice3.equalsIgnoreCase("a")) {
            System.out.println(dbProducts);
        }
        if (choice3.equalsIgnoreCase("b")) {
            genderMenu(dbProducts, scanner);
        }
        if (choice3.equalsIgnoreCase("c")) {
            System.out.println("Please input an ID of your choice");
            String idChoice = scanner.nextLine();
            Product product = getProductById(dbProducts, idChoice);
            Order order = new Order(product, "1");
            dbOrders.add(order);
            System.out.println("Your order is completed");
            System.out.println(dbOrders);


        }
        if (choice3.equalsIgnoreCase("d")) {
            userMenu(dbProducts, scanner, dbOrders, dbUsers);
        }
        if (choice3.equalsIgnoreCase("e")) {
            start(dbUsers, dbProducts, dbOrders);
        }
    }

    private static Product getProductById(ArrayList<Product> dbProducts, String idChoice) {
        return dbProducts.stream()
                .filter(it -> String.valueOf(it.id).equals(idChoice))
                .findFirst()
                .get();
    }

    private static void genderMenu(ArrayList<Product> dbProducts, Scanner scanner) {
        System.out.println("Input Gender");
        System.out.println("1. For boys");
        System.out.println("2. For girls");
        final int genderChoice = scanner.nextInt();
        scanner.nextLine();                    // skip /n
        if (genderChoice == 1) {
            ArrayList<Product> boyProduct = new ArrayList<>();
            boyProduct.addAll(dbProducts.stream().
                    filter(currentProduct -> currentProduct.sex == "boy")
                    .collect(Collectors.toList())
            );
            System.out.println(boyProduct);
            System.out.println("Products categories: ");
            System.out.println("1. Outwear");
            System.out.println("2. Trousers");
            System.out.println("3. Shirts");
            System.out.println("4. Suits");
            System.out.println("5. Shoes");
            String choiceBoyCategory = scanner.nextLine();
            ArrayList<Product> categoryProducts = new ArrayList<>();
            switch (choiceBoyCategory) {
                case "1":
                    categoryProducts.addAll(boyProduct.stream().filter(it -> it.category == "OUTWEAR")
                            .collect(Collectors.toList()));
                    break;
                case "2":
                    categoryProducts.addAll(boyProduct.stream().filter(it -> it.category == "TROUSERS")
                            .collect(Collectors.toList()));
                    break;
                case "3":
                    categoryProducts.addAll(boyProduct.stream().filter(it -> it.category == "SHIRTS")
                            .collect(Collectors.toList()));
                    break;
                case "4":
                    categoryProducts.addAll(boyProduct.stream().filter(it -> it.category == "SUITS")
                            .collect(Collectors.toList()));
                    break;
                case "5":
                    categoryProducts.addAll(boyProduct.stream().filter(it -> it.category == "SHOES")
                            .collect(Collectors.toList()));
                    break;
                default:
                    System.out.println("No such clothes");

                    break;
            }

            System.out.println(categoryProducts);


        } else if (genderChoice == 2) {
            ArrayList<Product> girlProduct = new ArrayList<>();
            girlProduct.addAll(dbProducts.stream().filter(currentProduct -> currentProduct.sex
                    == "girl").collect(Collectors.toList())
            );
            System.out.println(girlProduct);
            System.out.println("Products categories: ");
            System.out.println("1. Outwear");
            System.out.println("2. Trousers");
            System.out.println("3. Blouses");
            System.out.println("4. Suits");
            System.out.println("5. Shoes");
            System.out.println("6. Dresses");
            System.out.println("7. Skirts");
            String choiceGirlCategory = scanner.nextLine();
            ArrayList<Product> categoryProducts = new ArrayList<>();

            switch (choiceGirlCategory) {
                case "1":
                    categoryProducts.addAll(girlProduct.stream().filter(it -> it.category == "OUTWEAR")
                            .collect(Collectors.toList()));
                    break;
                case "2":
                    categoryProducts.addAll(girlProduct.stream().filter(it -> it.category == "TROUSERS")
                            .collect(Collectors.toList()));
                    break;
                case "3":
                    categoryProducts.addAll(girlProduct.stream().filter(it -> it.category == "BLOUSES")
                            .collect(Collectors.toList()));
                    break;
                case "4":
                    categoryProducts.addAll(girlProduct.stream().filter(it -> it.category == "SUITS")
                            .collect(Collectors.toList()));
                    break;
                case "5":
                    categoryProducts.addAll(girlProduct.stream().filter(it -> it.category == "SHOES")
                            .collect(Collectors.toList()));
                    break;
                case "6":
                    categoryProducts.addAll(girlProduct.stream().filter(it -> it.category == "DRESSES")
                            .collect(Collectors.toList()));
                    break;
                case "7":
                    categoryProducts.addAll(girlProduct.stream().filter(it -> it.category == "SKIRTS")
                            .collect(Collectors.toList()));
                    break;
                default:
                    System.out.println("No such clothes");

                    break;
            }

            System.out.println(categoryProducts);
        }
        {

        }
    }
}


