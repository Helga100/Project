package com.company;

public enum OrderStatus {

    CONFIRM, UNCONFIRM

}
